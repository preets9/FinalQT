/********************************************************************************
** Form generated from reading UI file 'bramcal.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BRAMCAL_H
#define UI_BRAMCAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Bramcal
{
public:
    QLabel *label;

    void setupUi(QDialog *Bramcal)
    {
        if (Bramcal->objectName().isEmpty())
            Bramcal->setObjectName(QString::fromUtf8("Bramcal"));
        Bramcal->resize(1200, 1024);
        label = new QLabel(Bramcal);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 1200, 1024));
        label->setOpenExternalLinks(false);

        retranslateUi(Bramcal);

        QMetaObject::connectSlotsByName(Bramcal);
    } // setupUi

    void retranslateUi(QDialog *Bramcal)
    {
        Bramcal->setWindowTitle(QApplication::translate("Bramcal", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Bramcal: public Ui_Bramcal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BRAMCAL_H

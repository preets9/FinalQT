/********************************************************************************
** Form generated from reading UI file 'scarcal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCARCAL_H
#define UI_SCARCAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Scarcal
{
public:
    QLabel *imageLabel;

    void setupUi(QDialog *Scarcal)
    {
        if (Scarcal->objectName().isEmpty())
            Scarcal->setObjectName(QString::fromUtf8("Scarcal"));
        Scarcal->resize(2048, 1200);
        imageLabel = new QLabel(Scarcal);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        imageLabel->setGeometry(QRect(0, 0, 2048, 1200));

        retranslateUi(Scarcal);

        QMetaObject::connectSlotsByName(Scarcal);
    } // setupUi

    void retranslateUi(QDialog *Scarcal)
    {
        Scarcal->setWindowTitle(QCoreApplication::translate("Scarcal", "Dialog", nullptr));
        imageLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Scarcal: public Ui_Scarcal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCARCAL_H

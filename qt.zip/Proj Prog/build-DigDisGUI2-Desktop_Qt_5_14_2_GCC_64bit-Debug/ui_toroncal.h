/********************************************************************************
** Form generated from reading UI file 'toroncal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TORONCAL_H
#define UI_TORONCAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_toroncal
{
public:
    QLabel *label;

    void setupUi(QDialog *toroncal)
    {
        if (toroncal->objectName().isEmpty())
            toroncal->setObjectName(QString::fromUtf8("toroncal"));
        toroncal->resize(1200, 1024);
        label = new QLabel(toroncal);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 1200, 1024));

        retranslateUi(toroncal);

        QMetaObject::connectSlotsByName(toroncal);
    } // setupUi

    void retranslateUi(QDialog *toroncal)
    {
        toroncal->setWindowTitle(QCoreApplication::translate("toroncal", "Dialog", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class toroncal: public Ui_toroncal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TORONCAL_H

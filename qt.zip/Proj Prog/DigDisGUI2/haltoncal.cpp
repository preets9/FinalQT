#include "haltoncal.h"
#include "ui_haltoncal.h"

HaltonCal::HaltonCal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::HaltonCal)
{
    ui->setupUi(this);
    QPixmap pix("/home/pi/Downloads/FinalQT/Halton.png");
    ui->label->setPixmap(pix.scaled(1250,1100,Qt::KeepAspectRatio));



}

HaltonCal::~HaltonCal()
{
    delete ui;
}

#include "missical.h"
#include "ui_missical.h"
#include <QPixmap>
#include <QLabel>

Missical::Missical(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Missical)
{
    ui->setupUi(this);
    QPixmap pix("/home/pi/Downloads/FinalQT/Burlington.png");
    ui->label->setPixmap(pix.scaled(1250,1100,Qt::KeepAspectRatio));
}

Missical::~Missical()
{
    delete ui;
}

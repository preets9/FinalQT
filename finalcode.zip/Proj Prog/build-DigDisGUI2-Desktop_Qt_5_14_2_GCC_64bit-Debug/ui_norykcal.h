/********************************************************************************
** Form generated from reading UI file 'norykcal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NORYKCAL_H
#define UI_NORYKCAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_norykcal
{
public:
    QLabel *labelpic;

    void setupUi(QDialog *norykcal)
    {
        if (norykcal->objectName().isEmpty())
            norykcal->setObjectName(QString::fromUtf8("norykcal"));
        norykcal->resize(1200, 1024);
        labelpic = new QLabel(norykcal);
        labelpic->setObjectName(QString::fromUtf8("labelpic"));
        labelpic->setGeometry(QRect(0, 0, 1200, 1024));

        retranslateUi(norykcal);

        QMetaObject::connectSlotsByName(norykcal);
    } // setupUi

    void retranslateUi(QDialog *norykcal)
    {
        norykcal->setWindowTitle(QCoreApplication::translate("norykcal", "Dialog", nullptr));
        labelpic->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class norykcal: public Ui_norykcal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NORYKCAL_H
